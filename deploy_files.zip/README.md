# Validador de PDF — Guia para usuário (passo a passo)

Este pacote contém um script em Python que valida PDFs/imagens segundo o modelo de
"DECLARAÇÃO DE RECEBIMENTO DE MATERIAL DE LIMPEZA" e grava o resultado em uma planilha Excel.

Arquivos incluídos (em `deploy_files.zip`):

- `validate_pdf_standard.py` — script principal (Python)
- `requirements.txt` — dependências Python (instalar com `pip`)
- `README.md` — este guia passo a passo
- `learned_patterns.json` — dados de aprendizado (modelos já reconhecidos)
- `por.traineddata` — dados de idioma Português para o Tesseract (caso sua instalação não o contenha)
- `run_validate.bat` — atalho para executar o script com dois cliques

--------------------------------------------------------------------------------

Guia rápido — passo a passo para quem nunca programou
====================================================

Siga cada passo com atenção. Se algo não funcionar, copie a mensagem do erro e peça ajuda.

1) Extraia os arquivos

   - Clique com o botão direito em `deploy_files.zip` → `Extrair Tudo...` → escolha uma pasta (ex.: `C:\Users\%USERNAME%\Documents\Leitor de PDF`) → `Extrair`.

2) Instale o Python (se ainda não tiver)

   - Abra <https://www.python.org/downloads/>
   - Baixe o instalador recomendado (Python 3.11+).
   - Execute o instalador e marque **Add Python to PATH** antes de clicar em **Install Now**.

3) Abra o Prompt de Comando (cmd)

   - Pressione `Win + R`, digite `cmd` e pressione Enter.

4) Vá até a pasta do projeto

```cmd
cd "C:\Users\%USERNAME%\Documents\Leitor de PDF"
```

5) Instale as dependências Python (uma vez)

```cmd
python -m pip install -r requirements.txt
```

6) Instale o Tesseract (OCR)

- Recomendado para leigos: baixe a build do UB-Mannheim e execute o instalador:
  - <https://github.com/UB-Mannheim/tesseract/wiki>

Verifique no `cmd`:

```cmd
tesseract --version
tesseract --list-langs
```

Se `por` estiver na lista, perfeito. Se não aparecer, não se preocupe — há um `por.traineddata` incluído na pasta do projeto e o script tentará usá-lo automaticamente.

7) Executar o script — opção simples (dois cliques)

- Dê um duplo clique em `run_validate.bat` dentro da pasta do projeto. O terminal abrirá e o script iniciará; siga as instruções na tela.

8) Executar o script — opção via linha de comando

```cmd
python validate_pdf_standard.py
```

Para evitar prompts você pode passar a planilha e o tesseract diretamente:

```cmd
python validate_pdf_standard.py "C:\caminho\para\sua_planilha.xlsx" --tesseract-cmd "C:\Program Files\Tesseract-OCR\tesseract.exe"
```

9) O que o script faz

- Lê os caminhos dos arquivos (PDF/imagem) na **coluna G** da planilha.
- Escreve o resultado em **coluna M** como `Documento Aprovado` ou `Documento Reprovado`.
- Salva backups automáticos da planilha original.

Problemas comuns e soluções rápidas
---------------------------------

- `tesseract: command not found` → instale o Tesseract ou rode com `--tesseract-cmd` apontando o executável.
- Se o idioma `por` não estiver disponível, coloque `por.traineddata` em `C:\Program Files\Tesseract-OCR\tessdata` ou deixe o arquivo que veio no ZIP na pasta do projeto.
- Mensagem `Arquivo não encontrado` para caminhos de rede (UNC) → copie os PDFs para uma pasta local antes de rodar.

Precisa de ajuda?
---------------

Cole aqui a mensagem do erro que apareceu no terminal (ou uma captura de tela) que eu te oriento nos próximos passos.

---

O arquivo `validate_pdf_standard.py` contém a lógica completa de validação e o uso do `learned_patterns.json`.
```markdown
## Validador de PDF — instruções rápidas e práticas

Este repositório contém o script principal `validate_pdf_standard.py` que valida se um PDF/arquivo de imagem segue o padrão de
"DECLARAÇÃO DE RECEBIMENTO DE MATERIAL DE LIMPEZA" e escreve o resultado na coluna M da planilha (caminhos na coluna G).

O arquivo `deploy_files.zip` incluído contém tudo o que você precisa para rodar o script localmente (veja seção "O que está incluído").

Este README foi simplificado com passos claros para você — mesmo que nunca tenha programado — preparar o ambiente e executar o script.

**O que está incluído no `deploy_files.zip`**

- `validate_pdf_standard.py` — o script principal (Python).
- `requirements.txt` — lista de dependências Python (instaladas via `pip`).
- `README.md` — este arquivo com instruções.
- `learned_patterns.json` — base de aprendizado usada pelo script (modelos/template já aprendidos).
- `por.traineddata` — arquivo de idioma Português para o Tesseract (caso sua instalação do Tesseract não o inclua).

## Passo a passo simples (para usuário leigo)

Siga estes passos exatamente. Se ficar travado, copie o erro e peça ajuda.

1) Descompactar o `deploy_files.zip`

   - Clique com o botão direito em `deploy_files.zip` → `Extrair Tudo...` → escolha uma pasta (ex.: `C:\Users\%USERNAME%\Documents\Leitor de PDF`) e clique em `Extrair`.

2) Instalar o Python (se ainda não tiver)

   - Acesse https://www.python.org/downloads/ e baixe o instalador recomendado para Windows (ex.: Python 3.11 ou superior).
   - Execute o instalador e marque a caixa **Add Python to PATH** antes de clicar em `Install Now`.

3) Abrir o `Prompt de Comando` (cmd.exe)

   - Pressione `Win + R`, digite `cmd` e pressione Enter.

4) Ir até a pasta extraída

   - No `cmd`, cole (substitua pelo caminho onde extraiu):

```cmd
cd "C:\Users\%USERNAME%\Documents\Leitor de PDF"
```

5) Instalar dependências Python

   - No `cmd`, rode:

```cmd
python -m pip install -r requirements.txt
```

- Aguarde até terminar (pode demorar alguns minutos na primeira execução).

6) Instalar o Tesseract (OCR) — passo opcional imediato

   - O Tesseract é um programa separado que o script usa para ler textos em imagens.
   - Se você já instalou o Tesseract (ex.: via instalador do UB Mannheim ou via Scoop/Chocolatey), pule este passo.
   - Para usuários leigos recomendamos o instalador do UB Mannheim (faz tudo automaticamente):

     1. Abra https://github.com/UB-Mannheim/tesseract/wiki e baixe a build para Windows.
     2. Execute o instalador padrão (aceite os padrões). Ao terminar, o Tesseract normalmente ficará em `C:\Program Files\Tesseract-OCR\`.
   - Verificar instalação no `cmd`:

```cmd
tesseract --version
tesseract --list-langs
```

- Se o Tesseract reportar a língua `por`, ótimo. Se não, nós incluímos `por.traineddata` na pasta do projeto — o script tentará usar esse arquivo automaticamente.

7) Executar o script (modo simples, interativo)

   - No `cmd`, estando na pasta do projeto, apenas rode:

```cmd
python validate_pdf_standard.py
```

- O script irá perguntar pela planilha se não receber o caminho como argumento. Só responda com o caminho da sua planilha quando solicitado, por exemplo:

```
C:\Users\%USERNAME%\Documents\Leitor de PDF\material de limpeza.xlsx
```

- Se o script não encontrar automaticamente o `tesseract.exe`, ele pedirá o caminho. Se você instalou pelo UB-Mannheim, o caminho provavelmente é:

```
C:\Program Files\Tesseract-OCR\tesseract.exe
```

8) Executar o script (modo direto, sem perguntas)

   - Se quiser passar a planilha e o caminho do tesseract na linha de comando (sem prompts), execute algo assim:

```cmd
python validate_pdf_standard.py "C:\Users\%USERNAME%\Documents\Leitor de PDF\material de limpeza.xlsx" --tesseract-cmd "C:\Program Files\Tesseract-OCR\tesseract.exe"
```

9) Resultado na planilha

   - O script lê caminhos na **coluna G** e grava o status em **coluna M**.
   - A planilha original será salva com backup automático pelo script.
10) Problemas comuns e soluções rápidas

- Mensagem: `tesseract: command not found` → instale o Tesseract ou passe o caminho com `--tesseract-cmd`.
- Mensagem: `Idioma por não encontrado` → abra o `cmd` e rode `tesseract --list-langs`. Se `por` não estiver, verifique se há `por.traineddata` em `C:\Program Files\Tesseract-OCR\tessdata` ou mantenha o `por.traineddata` que veio no ZIP na mesma pasta do script (o script tenta usá-lo automaticamente).
- Arquivos em rede (UNC) dando erro `Arquivo não encontrado` → copie os PDFs para uma pasta local antes de rodar.

## Se quiser ajuda extra

- Me envie uma captura do erro ou cole o texto do `cmd` aqui.

---

Arquivo: `validate_pdf_standard.py` — mantém toda a lógica de validação, OCR forçado e aprendizado (`learned_patterns.json`). Este README apenas documenta como preparar e executar o script de forma simples e reproduzível.

```
# Validador de PDF — instruções rápidas e práticas

Este repositório contém o script principal `validate_pdf_standard.py` que valida se um PDF/arquivo de imagem segue o padrão de
"DECLARAÇÃO DE RECEBIMENTO DE MATERIAL DE LIMPEZA" e escreve o resultado na coluna M da planilha (caminhos na coluna G).

Este README foi simplificado com passos claros para você (ou outro programador) preparar o ambiente e executar o script.

## 1) Instalar dependências Python

- Abra `cmd.exe` no Windows e rode:

```cmd
python -m pip install -r requirements.txt
```

O `requirements.txt` deve conter (já incluso):

- PyMuPDF
- openpyxl
- pytesseract
- Pillow
- rapidfuzz

## 2) Onde definir o caminho da planilha

- O script aceita um argumento posicional `path` para um PDF ou para a planilha `.xlsx`.
- Se você não passar o `path`, o script perguntará interativamente qual planilha usar; ao pressionar Enter ele tentará o caminho padrão:

  `C:\Users\victor.vasconcelos\Documents\Leitor de PDF\material de limpeza.xlsx`
- Exemplo (processar a planilha explicitamente):

```cmd
"C:\...\python.exe" validate_pdf_standard.py "C:\Users\victor.vasconcelos\Documents\Leitor de PDF\material de limpeza.xlsx"
```

## 3) Tesseract (OCR) — instalação e apontamento

Observação: o Tesseract é um binário nativo (não instalado via pip). O pacote `pytesseract` no `requirements.txt` permite controlar o binário, mas o executável precisa estar instalado.

Opções de instalação no Windows (passo a passo):

- a) Via Scoop (sem privilégios de administrador):

  Abra PowerShell como usuário normal e rode:

  ```powershell
  Set-ExecutionPolicy RemoteSigned -Scope CurrentUser
  iwr -useb get.scoop.sh | iex
  scoop install tesseract
  ```

  Após isso, verifique no cmd:

  ```cmd
  tesseract --version
  ```
- b) Via Chocolatey (se você tiver Chocolatey):

  ```powershell
  choco install tesseract
  ```
- c) Via Conda (se preferir instalar dentro do ambiente conda):

  ```cmd
  conda install -c conda-forge tesseract pytesseract pillow
  ```
- d) Build portátil / ZIP (baixar manualmente):

  - Baixe uma build para Windows (ex.: repositório oficial: https://github.com/tesseract-ocr/tesseract; builds Windows comuns: https://github.com/UB-Mannheim/tesseract/wiki )
  - Extraia em `C:\Users\<seu_user>\tools\tesseract\` e garanta a pasta `tessdata` com `por.traineddata` presente.

Depois de instalar, você pode apontar explicitamente o executável quando chamar o script usando a flag `--tesseract-cmd`:

```cmd
"C:\...\python.exe" validate_pdf_standard.py "C:\path\to\sheet.xlsx" --tesseract-cmd "C:\Users\me\tools\tesseract\tesseract.exe"
```

O script também tenta detectar `tesseract` automaticamente em locais comuns (Scoop, conda, PATH). Se não encontrar, e se estiver rodando em um terminal interativo, ele perguntará pelo caminho do `tesseract.exe`.

## 4) Exemplo completo de execução (Windows, cmd.exe)

- Rodar interativo (script perguntará planilha e tesseract se necessário):

```cmd
"C:\...\python.exe" validate_pdf_standard.py
```

- Rodar não interativo (passando planilha e tesseract):

```cmd
"C:\...\python.exe" validate_pdf_standard.py "C:\Users\victor.vasconcelos\Documents\Leitor de PDF\material de limpeza.xlsx" --tesseract-cmd "C:\Users\victor.vasconcelos\scoop\shims\tesseract.exe"
```

- Se quiser pular cabeçalho diferente (0 linhas de cabeçalho):

```cmd
... validate_pdf_standard.py "...\material de limpeza.xlsx" --header-rows 0
```

## 5) Saída e colunas da planilha

- O script lê caminhos na **coluna G** (coluna 7) e grava o resultado em **coluna M** (coluna 13).
- O resultado na coluna M será **"Documento Aprovado"** ou **"Documento Reprovado"**. A coluna N (14) contém notas/audit trail (por exemplo: motivo da reprovação ou se foi auto-aprovado pelo aprendizado).

## 6) Boas práticas para performance (sem alterar lógica)

- Se os arquivos estão em um servidor de rede (UNC) e o processamento for grande, copie os PDFs localmente antes de rodar para reduzir latência (ex.: `C:\data\dec_kli`). Use `robocopy` para grandes cópias.
- Evite abrir/salvar o Excel a cada arquivo: prefira rodar o script como está (ele já aplica saves periódicos), ou use modos em lote/parallel conforme necessário (avançado).

## 7) Dicas de depuração

- Se o OCR falhar por ausência de idioma em português, coloque `por.traineddata` em `tessdata` do executável Tesseract ou na pasta do script; o script também tentará definir `TESSDATA_PREFIX` automaticamente quando encontrar esse arquivo.
- Se o script não encontrar `tesseract` automaticamente, rode com `--tesseract-cmd` apontando o executável.

## 8) Links úteis

- Projeto Tesseract (fonte): https://github.com/tesseract-ocr/tesseract
- Windows builds / UB Mannheim (com builds prontos): https://github.com/UB-Mannheim/tesseract/wiki

Arquivo: `validate_pdf_standard.py` — mantém toda a lógica de validação, OCR forçado e aprendizado (`learned_patterns.json`). Este README apenas documenta como preparar e executar o script de forma simples e reproduzível.
